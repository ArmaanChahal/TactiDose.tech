# CareBridge UI update

## Install

Back up your existing `ui` folder, then replace it with the `ui` folder in this archive at the same location in your project. Restart your app if needed and hard-refresh the browser (Cmd+Shift+R on macOS). No packages, build step, API changes or database migration are required.

## Changes

- Updated displayed branding to CareBridge. Existing lowercase `tactidose` storage keys and custom events remain compatible with the app.
- Removed the top healthy-connection “Live” badge on every page. Reconnection and offline warnings still appear.
- Added a restrained green/neutral palette, clearer navigation, consistent borders and more balanced spacing across patient, care, sign-in, kiosk and demo screens.
- Reworked sign-in into a simple explanatory column and familiar form on wider screens; stacks on narrow screens.
- Preserved the patient portal's 24px base text, large primary actions, keyboard focus, skip links, hidden states and all existing control IDs.
- Retained dark and yellow-on-black contrast themes and all text-size settings. Existing saved preferences take priority. New users start with the light theme.
- No external fonts, gradients, decorative animations or new dependencies.

## Functionality preserved

All original API calls, form submission logic, authentication behavior, dose controls, voice handling, event subscriptions, tab behavior, notifications and report logic remain unchanged, apart from displayed brand wording. Connection-indicator visibility and the default theme are the only intentional JavaScript behavior changes.

## Checks performed

- All five pages retain every original element ID, with no duplicate IDs.
- Every JavaScript module passes Node syntax validation.
- Connection-handler checks confirm connected status is hidden and reconnect/offline warnings remain visible.
- Theme checks confirm saved light/dark/yellow preferences and extra-large text settings are retained.
- Compared JavaScript against the uploaded archive to verify application behavior is unchanged outside the two display changes above.

Visual browser preview was unavailable in this environment, so desktop/mobile rendering and full backend interactions have not been visually verified. Check the pages in your running app before presenting, especially extra-large text and device actions. No mock data or preview server is included in this archive.
